########################################################################/
# Talleres de Iniciación en R ------
# Sesión 3: Lectura y exploración de datos 
# Aproximación a las políticas públicas desde los datos - 01/07/2023
########################################################################/
# Lectura, exploración y manipulación de datos en R
# José Daniel Conejeros - jdconejeros@uc.cl
########################################################################/

# En este taller nos enfocaremos en una introducción a R para el procesamiento datos. 

# Para instala R en tu computador: https://cran.r-project.org/
# Para instala RStudio en tu computador: https://posit.co/download/rstudio-desktop/


# En este taller nos enfocaremos en introducir las herramientas básicas para la exploración de datos

# De ahora en adelante vamos a trabajar con algunas ajustes en la configuración
rm(list = ls()) # Para limpiar el espacio de trabajo
options(scipen=999) # Desactiva la notación científica y ayuda a la lectura de números

########################################################################/
## Tema 1: Paquetes  ----
########################################################################/

# Instalemos un paquete útil
install.packages("tidyverse") # Todas las herramientas para análisis de datos
library(tidyverse)
library(dplyr)
dplyr::filter() #Llamar funciones de la libreria
library(help = "dplyr")

#Funciones base de R
library(help = "base") 
search() #Revisamos los paquetes y herramientas instaladas

# Cargamos una librería con descriptivos 
install.packages("Hmisc")
library(Hmisc)

search() #Revisamos si aparece Hmisc

########################################################################/
## Tema 2: Importar una base de datos  ----
########################################################################/

# Las tablas de datos en general están en diversos formatos, por lo que
# debemos aplicar funciones para que puedan ser trabajadas en este espacio de trabajo
# Podemos realizar esto de forma manual, ¿Cuál es la desventaja de esto?

#### 2.1 Base en formato .txt  ----
# TXT: Documento de texto plano
data_txt <- read.table(file="input/simce2m2016_extracto.txt", sep="\t")
#data_txt <- read.table(file="input\simce2m2016_extracto.txt", sep="\t")

#### 2.2 Base en formato .csv  ----
# CSV: Valores separados por comas
data_csv <- read.csv("input/simce2m2016_extracto.csv")
#data_csv <- read.csv("input\simce2m2016_extracto.csv")

#### 2.3 Base en formato .xlsx  ----
install.packages("readxl")
library(readxl)

data_xlsx <- read_xlsx(path="input/simce2m2016_extracto.xlsx")
#data_xlsx <- read_xlsx(path="input\simce2m2016_extracto.xlsx")

#### 2.4 Base en formato .sav  ----
install.packages("haven")
library(haven)
data_sav <- read_sav(file="input/simce2m2016_extracto.sav")
#data_sav <- read_sav(file="input\simce2m2016_extracto.sav")

#### 2.5 Base en formato .sas  ----
data_sas <- read_sas(data_file="input/simce2m2016_extracto.sas8bdat")
#data_sas <- read_sas(data_file="input\simce2m2016_extracto.sas8bdat")

#### 2.6 Base en formato .dta  ----
data_dta <- read_dta(file="input/simce2m2016_extracto.dta")
#data_dta <- read_dta(file="input\simce2m2016_extracto.dta")

#### 2.7 Base en formato .RData ----
load(file="input/simce2m2016_extracto.RData")
#load(file="input\simce2m2016_extracto.RData")

########################################################################/
## Tema 3: Estructura de una tabla de datos  ----
########################################################################/
ls() # Podemos ver los objetos del enviroment
rm(list=ls()) # Borramos todos los objetos

# Abrimos una tabla de datos para explorar
data <- read.csv("input/simce2m2016_extracto.csv")

# Exploramos el objeto
# Dada la heterogeneidad de nuestro objeto lo vamos a transformar en un marco de datos
typeof(data)
data <- as.data.frame(data)
class(data) # clase

# Realizamos una vista previa de los datos
View(data)

# Podemos ver los componentes del objeto 
dim(data)   # Observaciones y variables
colnames(data) # Nombre de nuestras variables 
str(data)   # Visor de nuestras variables

# Lógica fila, columna
data[1]
data[1,]
data[,1]
data[1,1]
data[1:6,1:6] # La separación para un objeto bidimensional es siempre fila, columna
data[,-6] # ¿Qué nos imprime esto?
data[,c(1, 3)] # Veamos la primera y última fila de una BBDD [fila, columna]
solo_mate <- data[,c("idalumno","ptje_mate2m_alu")] # ¿Cuál es la diferencia?

########################################################################/
## Tema 4: Explorar una base de datos  ----
########################################################################/

# Hay diversas funciones para explorar una tabla de datos, aquí veremos algunas-

### 4.1 Exploración inicial ----

# Cabeza de los datos
head(data)  # Primeras 6 observaciones
head(data, n=10)  # Primeras 10 observaciones
head(data[1,2])      # por nombres
head(data[[2]])    # por ubicación 

# Cola de los datos
tail(data, n=10)  # Últimas 10 observaciones
tail(data[,4], n=10)
tail(data[4,])
tail(data)
tail(15,15)
tail(1:20, 15)

# Podemos llamar a un vector dentro del marco de datos
data$idalumno
print(data$idalumno)

### 4.2 Variables y levels ----

# Consulta
install.packages("sjPlot")
library(sjPlot)
sjPlot::view_df(data)

# Etiqueta de variable
install.packages("Hmisc")
library(Hmisc)
label(data$gen_alu)
label(data$gen_alu) <- "Género del estudiante"

# Etiqueta de valores
unique(data$gen_alu)
levels(data$gen_alu)
table(data$gen_alu)

data$gen_alu <- as.factor(data$gen_alu)
levels(data$gen_alu)

###  4.3 Filtros de información ----
data2 <- data[data$cod_depe2 == "Municipal" & data$ptje_mate2m_alu<100, ] # Usemos condiciones 

data3 <- data[data$ptje_mate2m_alu %in% c(100:120),] # Comparar con varios valores
#data3 <- data[data$gen_alu %in% c("Femenino", "No binario"),]

data3b <- data[data$ptje_mate2m_alu >= 100 & data$ptje_mate2m_alu <= 120,] 

data4 <- data[data$ptje_mate2m_alu==100 | data$ptje_mate2m_alu==120, ] # Equivalente

### 4.4 Missing values ----

data$variable_missing <- NA
data$cpad_p08 <- ifelse(data$cpad_p08==8, NA, data$cpad_p08)

library(naniar) # Cargamos el paquete en nuestra sesión de trabajo 
library(ggplot2)

# % de missing según variable
vis_miss(data, warn_large_data = FALSE)
gg_miss_var(data) + scale_y_continuous(limits = c(0,60)) # Gráfico con el nivel de missing

n_var_miss(data) # Número de variables con casos pérdidos.

n_case_miss(data) # Número de casos con casos pérdidos.

# Upset graph
gg_miss_upset(data)

library(dplyr)
tabla_miss <- data %>%
  miss_var_summary() 

tabla_miss # vemos la tabla 

# Remover los missing
data_sin_miss <- na.omit(data)
dim(data_sin_miss)
head(data_sin_miss, n=20)

### 4.5 Generar nuevas -----

data$media_simce <- rowMeans(data[, c("ptje_mate2m_alu", "ptje_lect2m_alu")], na.rm=TRUE)

########################################################################/
## Tema 5: Exploración de datos ----
########################################################################/

# Estadísticos descriptivos en R-base
summary(data$media_simce)

mean(data$media_simce)
var(data$media_simce, na.rm=TRUE)
sd(data$media_simce, na.rm=TRUE)
range(data$media_simce, na.rm=TRUE)
min(data$media_simce, na.rm=TRUE)
max(data$media_simce, na.rm=TRUE)
quantile(data$media_simce, probs=0.25, na.rm=TRUE)
quantile(data$media_simce, probs=0.50, na.rm=TRUE)
quantile(data$media_simce, probs=0.75, na.rm=TRUE)

# Variables discretas: 
# - Frecuencia 
# - Frecuencia relativa
# - Porcentaje

table(data$gen_alu)
prop.table(table(data$gen_alu))
round(prop.table(table(data$gen_alu)),3)*100

# Podemos aplicar estos mismos análisis con dplyr:
tabla_descriptivos <- data %>%
  dplyr::summarize(count=length(na.omit(media_simce)),
                   media=mean(media_simce, na.rm=TRUE),
                   sd=sd(media_simce, na.rm=TRUE),
                   min=min(media_simce, na.rm=TRUE),
                   q25=quantile(media_simce, na.rm=TRUE, probs=0.25),
                   q50=quantile(media_simce, na.rm=TRUE, probs=0.50),
                   q75=quantile(media_simce, na.rm=TRUE, probs=0.75),
                   max=max(media_simce, na.rm=TRUE))

tabla_descriptivos 

writexl::write_xlsx(tabla_descriptivos, "output/tabla_descriptivos.xlsx")

# Para variables discretas esto se trabaja a través de los group_by()

tabla_frecuencias <- data %>% 
  dplyr::group_by(gen_alu) %>% 
  dplyr::summarise(n=n()) %>% 
  mutate(fr=n/sum(n), 
         porc=fr*100)

tabla_frecuencias

writexl::write_xlsx(tabla_frecuencias, "output/tabla_frecuencias.xlsx")

## 6.3 Análisis descriptivos bivariados ----

## Ejemplo 1: Me interesa saber el promedio de notas según género 

tabla_biv1 <- data %>%
  group_by(gen_alu) %>% 
  dplyr::summarize(count=length(na.omit(media_simce)),
                   media=mean(media_simce, na.rm=TRUE),
                   sd=sd(media_simce, na.rm=TRUE),
                   min=min(media_simce, na.rm=TRUE),
                   q25=quantile(media_simce, na.rm=TRUE, probs=0.25),
                   q50=quantile(media_simce, na.rm=TRUE, probs=0.50),
                   q75=quantile(media_simce, na.rm=TRUE, probs=0.75),
                   max=max(media_simce, na.rm=TRUE))

tabla_biv1

# Podemos exportar las tablas 
library(writexl)
write_xlsx(tabla_biv1, "output/Tabla_bivariada.xlsx")


########################################################################/
## Tema 6: Exportar datos ----
########################################################################/

#### 6.1 Base en formato .txt  ----
write.table(data, file="output/simce_modificada.txt", sep="\t")

#### 6.2 Base en formato .csv  ----
write.csv(data, file="output/simce_modificada.csv", row.names = FALSE)

#### 6.3 Base en formato .xlsx  ----
install.packages("writexl")
library(writexl)
write.xlsx(data, file="output/simce_modificada.xlsx")

#### 6.4 Base en formato .sav  ----
library(haven)
write_sav(data, "output/simce_modificada.sav")

#### 6.5 Base en formato .sas  ----
write_sas(data, "output/simce_modificada.sas8bdat")

#### 6.6 Base en formato .dta  ----
write_dta(data, "output/simce_modificada.dta")

#### 6.7 Base en formato .RData ----
save(data, file="output/simce_modificada.RData")

########################################################################/
# Ejercicio Propuesto ----
########################################################################/

# Explore la BBDD y trate de describir el siguiente código
install.packages("dplyr")
library(dplyr)
sum <- function(x, data){
  data %>%
    dplyr::summarize(count=length(na.omit({{ x }})),
                     media=mean({{ x }}, na.rm=TRUE),
                     sd=sd({{ x }}, na.rm=TRUE),
                     min=min({{ x }}, na.rm=TRUE),
                     q25=quantile({{ x }}, na.rm=TRUE, probs=0.25),
                     q50=quantile({{ x }}, na.rm=TRUE, probs=0.50),
                     q75=quantile({{ x }}, na.rm=TRUE, probs=0.75),
                     max=max({{ x }}, na.rm=TRUE))
}

sum(data=data, x=ptje_mate2m_alu)

# a. ¿Cuál es el input y el output de esta función? 

# b. ¿Para qué necesitaríamos la librería dplyr para aplicar esta función?

# c. ¿Qué hace el operador %>% (pipeline)?